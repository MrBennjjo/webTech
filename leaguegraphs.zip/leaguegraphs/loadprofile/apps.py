from django.apps import AppConfig


class LoadprofileConfig(AppConfig):
    name = 'loadprofile'
